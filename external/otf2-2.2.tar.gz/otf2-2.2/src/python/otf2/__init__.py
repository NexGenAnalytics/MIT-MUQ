__copyright__ = "Copyright (c) 2015-2016, Technische Universitaet Dresden, Germany"
__license__ = "BSD"
from _otf2 import __version__

from . import writer
from . import reader
from .enums import *
from . import events
from . import definitions
