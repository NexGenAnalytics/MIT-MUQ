This Visual Studio Project creates a static version of the otf2 library.
Visual Studio 2015 or higher is required to compile the library. The Library 
can only read otf2 traces without sion.
